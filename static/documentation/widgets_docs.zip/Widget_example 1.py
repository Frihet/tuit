from tuit.ticket.models import *
from django.contrib.auth import *


#
# Status columns
#

status_columns = ((_('Id of the issue'),'id'),(_('Priority'),'priority'),(_('Issue name'),'name'), ('Created', 'creation_date'),(_('Requester'),'requester'),(_('Tildelt'),'assigned_to'),(_('Sist oppd. av'),'last_updater'),(_('Medansv'),'co_responsible_string'),(_('Lokasjon'),'location'),(_('Status'),'current_status'))


status_closed = properties["issue_closed_id"]

#
# Here we get ids of the statuses that start with Venter
#

all_venter_id = []

all_venter_id.append(Status.objects.get(name = '05 Venter på svar fra buker').id)
all_venter_id.append(Status.objects.get(name = '06 Venter på svar fra buker, sendt purring').id)
all_venter_id.append(Status.objects.get(name = '07 Venter på svar fra tredjepart').id)

#
# Here we get all issues with status that start with Venter
#

issues_venter= Issue.objects.filter(current_status__in = all_venter_id).order_by('creation_date')


#
# Result has fomat
# result.append(Widget(_('Name of the widget'), items, request, 'slug_name', status_columns, class_names = "widget_2"))
# IMPORTANT!!! Slug name must be unique and without spaces
#
result = []

result.append(Widget(_('Example Widget'), issues_venter, request, 'example', status_columns,class_names = "widget_2"))
