from tuit.ticket.models import *
from django.contrib.auth import *


#
# Status columns
#

status_columns = ((_('Id of the issue'),'id'),(_('Priority'),'priority'),(_('Issue name'),'name'), ('Created', 'creation_date'),(_('Requester'),'requester'),(_('Tildelt'),'assigned_to'),(_('Sist oppd. av'),'last_updater'),(_('Medansv'),'co_responsible_string'),(_('Lokasjon'),'location'),(_('Status'),'current_status'))


status_closed = properties["issue_closed_id"]

#
# Here we get id of the status "04 Utsatt - etter avtale"
#

utsatt_id = Status.objects.get(name = '04 Utsatt - etter avtale').id

#
# Diferent types of items
#

issues_all = Issue.objects.order_by('creation_date')
issues_open = Issue.objects.exclude(current_status__in = status_closed).order_by('creation_date')
issues_unassigned = Issue.objects.filter(assigned_to__isnull = True).order_by('creation_date')
issues_utsatt = Issue.objects.filter(current_status = utsatt_id).order_by('-creation_date')


result = []

#
# Result has fomat
# result.append(Widget(_('Name of the widget'), items, request, 'slug_name', status_columns, class_names = "widget_2"))
#

result.append(Widget(_('Example Widget'), issues_all, request, 'example', status_columns,class_names = "widget_2"))
